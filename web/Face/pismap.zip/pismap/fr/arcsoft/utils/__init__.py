#-*- encoding=utf-8 -*-

class BufferInfo:
    def __init__(self,w, h, buf):
        self.width = w;
        self.height = h;
        self.buffer = buf;