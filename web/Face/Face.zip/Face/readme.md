# usage
pip install -r requirements.txt

python manage.py runsslserver 0.0.0.0:8888